from flask import Flask, request, jsonify
import joblib
import pandas as pd
import numpy as np

app = Flask(__name__)

# --- LOAD MODEL ---

print("--- MEMUAT MODEL ---")
try:
    # 1. Load file .pkl
    loaded_object = joblib.load("tesmultioutput_logreg.pkl")
    
    # 2. Cek apakah yang diload adalah Dictionary?
    if isinstance(loaded_object, dict):
        print(f"📦 File .pkl terdeteksi sebagai Dictionary. Keys: {loaded_object.keys()}")
        
        # Ambil model yang asli dari dalam dictionary
        # Berdasarkan analisis file kamu, key-nya bernama 'model'
        if 'model' in loaded_object:
            model = loaded_object['model']
            print("✅ Berhasil mengekstrak 'model' dari dictionary!")
        else:
            # Jika nama key beda, kita ambil item pertama saja
            print("⚠️ Key 'model' tidak ditemukan, mencoba mengambil item pertama...")
            model = list(loaded_object.values())[0]
    else:
        # Jika bukan dictionary, berarti langsung model
        model = loaded_object
        print("✅ File .pkl langsung berisi model.")

except Exception as e:
    print(f"❌ Gagal memuat model. Error: {e}")
    model = None

@app.route('/predict', methods=['POST'])
def predict():
    if model is None:
        return jsonify({'status': 'error', 'message': 'Model belum dimuat dengan benar di server.'})

    try:
        data = request.json
        print(f"📩 Data diterima: {data}")
        
        # 1. Siapkan DataFrame
        input_data = pd.DataFrame([{
            'age': float(data['age']),
            'BMI': float(data['BMI']),
            'sleep_hours': float(data['sleep_hours']),
            'sex': data['sex'],                 
            'physical_activity': data['physical_activity'] 
        }])

        # 2. Lakukan Prediksi
        prediction = model.predict(input_data)
        
        # Ubah hasil numpy array ke list
        result_list = prediction.tolist()[0] 
        
        # 3. Format Hasil & Konversi ke Float
        raw_result = {
            'diabetes': float(result_list[0]),
            'heart_attack': float(result_list[1]),
            'stroke': float(result_list[2]),
            'depression': float(result_list[3]),
            'cancer': float(result_list[4])
        }

        # 4. Bungkus dengan kunci 'data'
        response_json = {
            'status': 'success',
            'data': raw_result 
        }

        print(f"📤 Mengirim hasil: {response_json}")
        return jsonify(response_json)

    except Exception as e:
        print(f"⚠️ ERROR SAAT PREDIKSI: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)